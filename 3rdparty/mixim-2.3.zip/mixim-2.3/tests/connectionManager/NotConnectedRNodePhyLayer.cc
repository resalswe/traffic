#include "NotConnectedRNodePhyLayer.h"

Define_Module( NotConnectedRNodePhyLayer);
