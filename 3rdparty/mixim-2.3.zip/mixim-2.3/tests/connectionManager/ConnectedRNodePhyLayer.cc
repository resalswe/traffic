#include "ConnectedRNodePhyLayer.h"

Define_Module( ConnectedRNodePhyLayer);
